﻿namespace BlueBellDolls.Service.Settings
{
    internal class BlueBellDollsServiceSettings
    {

    }
}
