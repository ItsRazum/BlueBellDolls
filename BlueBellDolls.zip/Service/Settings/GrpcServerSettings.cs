﻿namespace BlueBellDolls.Service.Settings
{
    internal class GrpcServerSettings
    {
        public string Host { get; set; }
        public int Port { get; set; }

    }
}
