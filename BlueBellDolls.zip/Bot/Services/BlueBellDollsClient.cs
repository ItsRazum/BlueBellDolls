using BlueBellDolls.Grpc;

namespace BlueBellDolls.Bot.Services
{
    public class BlueBellDollsServiceClient : BlueBellDollsService.BlueBellDollsServiceClient
    {

    }
}
