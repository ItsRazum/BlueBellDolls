﻿using BlueBellDolls.Bot.Adapters;
using BlueBellDolls.Bot.Interfaces;
using BlueBellDolls.Bot.Settings;
using BlueBellDolls.Bot.Types.Generic;
using BlueBellDolls.Common.Interfaces;
using BlueBellDolls.Common.Models;
using Microsoft.Extensions.Options;

namespace BlueBellDolls.Bot.Commands
{
    public class ConfirmDeleteEntityCallback : CommandHandler<CallbackQueryAdapter>
    {
        private readonly BotSettings _botSettings;
        private readonly IDatabaseService _databaseService;
        private readonly IMessageParametersProvider _messageParametersProvider;

        public ConfirmDeleteEntityCallback(
            IBotService botService,
            IOptions<BotSettings> botSettings,
            IDatabaseService databaseService,
            IMessageParametersProvider messageParametersProvider)
            : base(botService)
        {
            _botSettings = botSettings.Value;
            _databaseService = databaseService;
            _messageParametersProvider = messageParametersProvider;

            Handlers = new()
            {
                { "confirm_deleteParentCat", HandleCallbackAsync<ParentCat> },
                { "confirm_deleteLitter", HandleCallbackAsync<Litter> },
                { "confirm_deleteKitten", HandleCallbackAsync<Kitten> },
            };
        }

        private async Task HandleCallbackAsync<TEntity>(CallbackQueryAdapter c, CancellationToken token) where TEntity : class, IDisplayableEntity
        {
            var entityId = int.Parse(c.CallbackData.Split('-').Last());
            (var entities, var pagesCount, var entitiesCount) = await _databaseService.ExecuteDbOperationAsync(async (unit, ct) =>
            {
                var repo = unit.GetRepository<TEntity>();
                var model = await repo.GetByIdAsync(entityId, ct);
                if (model != null)
                {
                    await repo.DeleteAsync(model, ct);
                    await unit.SaveChangesAsync(ct);
                }

                var pageSize = _botSettings.InlineKeyboardsSettings.PageSize;

                return (
                    await repo.GetByPageAsync(1, pageSize, ct),
                    await repo.PagesCountAsync(pageSize, ct),
                    await repo.CountAsync(ct));

            }, token);

            await BotService.EditMessageAsync(c.Chat, c.MessageId, _messageParametersProvider.GetEntityListParameters(entities, Enums.ListUnitActionMode.Edit, (1, pagesCount, entitiesCount)), token);
            await BotService.AnswerCallbackQueryAsync(c.CallbackId, "Модель успешно удалена!", token: token);
        }
    }
}
