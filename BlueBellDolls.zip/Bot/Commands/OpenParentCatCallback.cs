﻿using BlueBellDolls.Bot.Adapters;
using BlueBellDolls.Bot.Interfaces;
using BlueBellDolls.Bot.Types.Generic;
using BlueBellDolls.Common.Models;

namespace BlueBellDolls.Bot.Commands
{
    public class OpenParentCatCallback : CommandHandler<CallbackQueryAdapter>
    {
        private readonly IMessageParametersProvider _messageParametersProvider;
        private readonly IDatabaseService _databaseService;

        public OpenParentCatCallback(
            IBotService botService,
            IMessageParametersProvider messageParametersProvider,
            IDatabaseService databaseService) 
            : base(botService)
        {
            _messageParametersProvider = messageParametersProvider;
            _databaseService = databaseService;

            Handlers = new()
            {
                { "openParentCat", HandleCommandAsync },
            };
        }

        private async Task HandleCommandAsync(CallbackQueryAdapter c, CancellationToken token)
        {
            var args = c.CallbackData.Split('-'); //[0]Command, [1]ParentCatId, [2]LitterId
            var litterId = int.Parse(args.Last());
            var parentCatId = int.Parse(args[1]);
            

            var parentCat = await _databaseService.ExecuteDbOperationAsync(async (unit, ct) =>
            await unit.GetRepository<ParentCat>().GetByIdAsync(parentCatId, ct),
            token);

            if (parentCat == null)
            {
                await BotService.AnswerCallbackQueryAsync(c.CallbackId, "Не удалось найти сущность!", token: token);
                return;
            }

            await BotService.SendMessageAsync(c.Chat, _messageParametersProvider.GetParentCatFromLitterParameters(parentCat, litterId), token);
        }
    }
}
