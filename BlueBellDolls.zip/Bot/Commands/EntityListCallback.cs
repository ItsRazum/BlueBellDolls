﻿using BlueBellDolls.Bot.Adapters;
using BlueBellDolls.Bot.Interfaces;
using BlueBellDolls.Bot.Types.Generic;
using BlueBellDolls.Common.Interfaces;
using BlueBellDolls.Common.Models;

namespace BlueBellDolls.Bot.Commands
{
    public class EntityListCallback : CommandHandler<CallbackQueryAdapter>
    {
        private readonly IEntityHelperService _entityHelperService;
        private readonly IMessageParametersProvider _messageParametersProvider;

        public EntityListCallback(
            IBotService botService,
            IEntityHelperService entityHelperService,
            IMessageParametersProvider messageParametersProvider)
            : base(botService)
        {
            _entityHelperService = entityHelperService;
            _messageParametersProvider = messageParametersProvider;

            Handlers = new()
            {
                { "listParentCat", HandleCommandAsync<ParentCat> },
                { "listLitter", HandleCommandAsync<Litter> },
                { "listKitten", HandleCommandAsync<Kitten> }
            };
        }

        public async Task HandleCommandAsync<TEntity>(CallbackQueryAdapter c, CancellationToken token) where TEntity : class, IDisplayableEntity
        {
            var page = int.Parse(c.CallbackData.Split('-').Last());
            var (entityList, pagesCount, entitiesCount) = await _entityHelperService.GetEntityListAsync<TEntity>(page, token);
            await BotService.EditMessageAsync(
            c.Chat,
                c.MessageId,
                _messageParametersProvider.GetEntityListParameters(entityList, Enums.ListUnitActionMode.Edit, (page, pagesCount, entitiesCount)),
                token);
        }
    }
}
