﻿namespace BlueBellDolls.Bot.Settings
{
    public class GrpcClientSettings
    {
        public string Host { get; set; }
        public int Port { get; set; }

    }
}
