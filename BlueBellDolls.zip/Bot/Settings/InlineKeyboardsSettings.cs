﻿namespace BlueBellDolls.Bot.Settings
{
    public class InlineKeyboardsSettings
    {
        public int PageSize { get; set; }
    }
}
