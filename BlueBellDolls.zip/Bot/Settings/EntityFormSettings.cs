﻿namespace BlueBellDolls.Bot.Settings
{
    public class EntityFormSettings
    {
        public Dictionary<string, string> KittenProperties { get; set; }
        public Dictionary<string, string> ParentCatProperties { get; set; }
        public Dictionary<string, string> LitterProperties { get; set; }
    }
}
