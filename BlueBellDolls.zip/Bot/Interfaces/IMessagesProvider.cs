﻿using BlueBellDolls.Common.Interfaces;

namespace BlueBellDolls.Bot.Interfaces
{
    public interface IMessagesProvider
    {
        string CreateStartMessage();

        string CreateEntityFormMessage(IEntity entity);

        string CreateDeleteConfirmationMessage(IEntity entity);

        string CreateEntityListMessage<TEntity>(IEnumerable<TEntity> entities, int totalEntitiesCount) where TEntity : class, IDisplayableEntity;
    }
}