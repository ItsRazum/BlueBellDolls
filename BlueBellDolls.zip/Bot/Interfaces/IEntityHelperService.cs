﻿using BlueBellDolls.Common.Interfaces;

namespace BlueBellDolls.Bot.Interfaces
{
    public interface IEntityHelperService
    {
        Task<IDisplayableEntity?> GetDisplayableEntityByIdAsync<TEntity>(int entityId, CancellationToken token = default)
            where TEntity : IDisplayableEntity;

        Task<(IEnumerable<TEntity> entityList, int pagesCount, int entitiesCount)> GetEntityListAsync<TEntity>(int page, CancellationToken token = default)
            where TEntity : IDisplayableEntity;

        Task<TEntity> AddNewEntityAsync<TEntity>(CancellationToken token = default) 
            where TEntity : class, IDisplayableEntity, new();
    }
}
