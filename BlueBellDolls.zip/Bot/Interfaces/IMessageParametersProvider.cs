﻿using BlueBellDolls.Bot.Enums;
using BlueBellDolls.Bot.Types;
using BlueBellDolls.Common.Interfaces;
using BlueBellDolls.Common.Models;

namespace BlueBellDolls.Bot.Interfaces
{
    public interface IMessageParametersProvider
    {
        MessageParameters GetEntityMessageParameters(IDisplayableEntity entity);
        MessageParameters GetDeleteConfirmationParameters(string callback, IDisplayableEntity entity);
        public MessageParameters GetEntityListParameters<TEntity>(
            IEnumerable<TEntity> entities, 
            ListUnitActionMode actionMode, 
            (int page, int totalPagesCount, int totalEntitiesCount) pageParameters) 
            where TEntity : class, IDisplayableEntity;
        MessageParameters GetParentCatFromLitterParameters(ParentCat parentCat, int litterId);
    }
}