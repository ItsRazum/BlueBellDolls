﻿namespace BlueBellDolls.Bot.Enums
{
    public enum ListUnitActionMode
    {
        Edit,
        Select
    }
}
