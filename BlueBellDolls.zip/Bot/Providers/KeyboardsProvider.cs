﻿using BlueBellDolls.Bot.Enums;
using BlueBellDolls.Bot.Extensions;
using BlueBellDolls.Bot.Interfaces;
using BlueBellDolls.Common.Interfaces;
using BlueBellDolls.Common.Models;
using Telegram.Bot.Types.ReplyMarkups;

namespace BlueBellDolls.Bot.Providers
{
    public class KeyboardsProvider : IKeyboardsProvider
    {

        #region Fields

        private readonly Dictionary<Type, Func<IDisplayableEntity, InlineKeyboardMarkup>> _entityOptionsKeyboards;

        #endregion

        #region Constructor

        public KeyboardsProvider()
        {
            _entityOptionsKeyboards = new()
            {
                { typeof(ParentCat), (entity) => CreateParentCatOptions((ParentCat)entity) },
                { typeof(Litter),    (entity) => CreateLitterOptionsKeyboard((Litter)entity) },
                { typeof(Kitten),    (entity) => CreateKittenOptions((Kitten)entity) },
            };
        }

        #endregion

        #region IKeyboardsProvider implementation

        public InlineKeyboardMarkup CreateEntityListKeyboard<TEntity>(IEnumerable<TEntity> entities, ListUnitActionMode actionMode = ListUnitActionMode.Edit, (int page, int totalPagesCount)? pageParameters = null) where TEntity : class, IDisplayableEntity
        {
            var result = new InlineKeyboardMarkup();
            foreach (var entity in entities)
                result.AddNewRow(CreateEntityReferenceButton(entity, actionMode));

            if (pageParameters != null)
                result.AddNewRow(CreatePageControlsButtons<TEntity>(pageParameters.Value));

            if (typeof(TEntity) != typeof(Kitten))
                result.AddNewRow(CreateAddButton<TEntity>());

            return result;
        }

        public InlineKeyboardMarkup CreateEntityOptionsKeyboard(IDisplayableEntity entity)
        {
            var result = new InlineKeyboardMarkup(CreateBackToEntityListButton(entity));

            foreach (var row in _entityOptionsKeyboards[entity.GetType()](entity).InlineKeyboard)
                result.AddNewRow(row.ToArray());

            return result;
        }

        public InlineKeyboardMarkup CreateConfirmEntityDeletionKeyboard(string callback, IDisplayableEntity entity)
        {
            return new InlineKeyboardMarkup([
                [
                    InlineKeyboardButton.WithCallbackData("Да", $"confirm_{callback}"), 
                    InlineKeyboardButton.WithCallbackData("Нет", $"edit{entity.GetType().Name}-{entity.Id}")
                ]
            ]);
        }

        public InlineKeyboardMarkup CreateParentCatFromLitterKeyboard(ParentCat parentCat, int litterId)
        {
            var result = new InlineKeyboardMarkup(CreateBackToLitterButton(litterId));
            
            foreach(var row in CreateParentCatOptions(parentCat).ToEnumerable())
                result.AddNewRow(row);

            return result;
        }

        #endregion

        #region Methods

        private InlineKeyboardMarkup CreateLitterOptionsKeyboard(Litter litter)
        {
            var result = CreateEntityListKeyboard(litter.Kittens);

            if (litter.Kittens.Count < 10)
                result.AddNewRow(InlineKeyboardButton.WithCallbackData("Добавить котёнка", $"addToLitter-{litter.Id}"));

            (string motherButtonText, string motherButtonCallbackData) = (
                "Мама",
                litter.MotherCatId != null
                ? $"openParentCat-{litter.MotherCatId}-{litter.Id}"
                : $"selectMotherCat-{litter.Id}"
                );

            (string fatherButtonText, string fatherButtonCallbackData) = (
                "Папа",
                litter.FatherCatId != null
                ? $"openParentCat-{litter.FatherCatId}-{litter.Id}"
                : $"selectFatherCat-{litter.Id}"
                );

            result.AddNewRow([
                InlineKeyboardButton.WithCallbackData(motherButtonText, motherButtonCallbackData),
                InlineKeyboardButton.WithCallbackData(fatherButtonText, fatherButtonCallbackData)
                ]);


            result.AddNewRow(CreateDeleteButton(litter));

            return result;
        }

        private InlineKeyboardMarkup CreateParentCatOptions(ParentCat parentCat)
        {
            return CreateDeleteButton(parentCat);
        }

        private InlineKeyboardMarkup CreateKittenOptions(Kitten entity)
        {
            var result = new InlineKeyboardMarkup();
            result.AddNewRow(CreateBackToLitterButton(entity.LitterId));
            result.AddNewRow(CreateDeleteButton(entity));
            return result;
        }

        private InlineKeyboardButton[] CreatePageControlsButtons<TEntity>((int page, int totalPagesCount) pageParameters)
        {
            var entityName = typeof(TEntity).Name;
            var pageCounterString = pageParameters.totalPagesCount == 0
                ? "Список пуст!"
                : $"{pageParameters.page}/{pageParameters.totalPagesCount}";
            var result = new List<InlineKeyboardButton?>
            {
                pageParameters.page > 1
                ? InlineKeyboardButton.WithCallbackData("«", $"list{entityName}-{pageParameters.page - 1}")
                : null,
                InlineKeyboardButton.WithCallbackData(pageCounterString),
                pageParameters.page < pageParameters.totalPagesCount
                ? InlineKeyboardButton.WithCallbackData("»", $"list{entityName}-{pageParameters.page + 1}")
                : null
            };

            return [.. result.Where(b => b != null)];
        }

        private InlineKeyboardButton CreateBackToEntityListButton(IDisplayableEntity entity)
        {
            var entityName = entity.GetType().Name;
            return InlineKeyboardButton.WithCallbackData($"Открыть лист {entityName}", $"list{entityName}-1");
        }

        private InlineKeyboardButton CreateBackToLitterButton(int litterId)
            => InlineKeyboardButton.WithCallbackData("Открыть помёт", $"form{nameof(Litter)}-{litterId}");

        private InlineKeyboardButton CreateDeleteButton(IDisplayableEntity entity)
            => InlineKeyboardButton.WithCallbackData($"Удалить {entity.DisplayName}", $"delete{entity.GetType().Name}-{entity.Id}");

        private InlineKeyboardButton CreateEntityReferenceButton(IDisplayableEntity entity, ListUnitActionMode actionMode)
            => InlineKeyboardButton.WithCallbackData(entity.DisplayName, $"{actionMode.ToString().ToLower()}{entity.GetType().Name}-{entity.Id}");

        private InlineKeyboardButton CreateAddButton<TEntity>() where TEntity : class, IDisplayableEntity
            => InlineKeyboardButton.WithCallbackData("Добавить ещё", $"add{typeof(TEntity).Name}");

        #endregion

    }
}
