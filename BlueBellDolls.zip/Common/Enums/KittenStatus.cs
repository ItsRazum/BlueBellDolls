﻿namespace BlueBellDolls.Common.Enums
{
    public enum KittenStatus
    {
        Available,
        Reserved,
        UnderObservation,
        Sold
    }
}
