﻿namespace BlueBellDolls.Common.Enums
{
    public enum LitterStatus
    {
        Active,
        Inactive
    }
}
