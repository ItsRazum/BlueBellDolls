﻿namespace BlueBellDolls.Common.Enums
{
    public enum KittenClass
    {
        Pet,
        Breed,
        Show
    }
}
