﻿namespace BlueBellDolls.Common.Interfaces
{
    public interface IDisplayableEntity : IEntity
    {
        string DisplayName { get; }

    }
}
